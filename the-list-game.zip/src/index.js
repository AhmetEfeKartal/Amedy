import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import "./index.css";

const TARGET_LIST = ["Bangkok", "London", "Paris", "Dubai", "Singapore"];
const MAX_ATTEMPTS = 6;
const LIST_LENGTH = 5;

function getFeedback(guess, target) {
  return guess.map((item, index) => {
    if (item.toLowerCase() === target[index].toLowerCase()) return "green";
    if (target.some(t => t.toLowerCase() === item.toLowerCase())) return "yellow";
    return "gray";
  });
}

function TheListGame() {
  const [guesses, setGuesses] = useState([]);
  const [currentGuess, setCurrentGuess] = useState(Array(LIST_LENGTH).fill(""));
  const [feedbacks, setFeedbacks] = useState([]);
  const [gameOver, setGameOver] = useState(false);

  const handleChange = (value, index) => {
    const newGuess = [...currentGuess];
    newGuess[index] = value;
    setCurrentGuess(newGuess);
  };

  const handleSubmit = () => {
    const feedback = getFeedback(currentGuess, TARGET_LIST);
    setGuesses([...guesses, currentGuess]);
    setFeedbacks([...feedbacks, feedback]);
    if (currentGuess.join().toLowerCase() === TARGET_LIST.join().toLowerCase() || guesses.length + 1 >= MAX_ATTEMPTS) {
      setGameOver(true);
    }
    setCurrentGuess(Array(LIST_LENGTH).fill(""));
  };

  return (
    <div className="container">
      <h2>Guess the Top 5 Most Visited Cities in the World</h2>
      {guesses.map((guess, i) => (
        <div className="row" key={i}>
          {guess.map((item, j) => (
            <div key={j} className={`box ${feedbacks[i][j]}`}>{item}</div>
          ))}
        </div>
      ))}
      {!gameOver && (
        <div className="row">
          {currentGuess.map((val, i) => (
            <input
              key={i}
              className="input-box"
              value={val}
              onChange={(e) => handleChange(e.target.value, i)}
            />
          ))}
          <button onClick={handleSubmit}>Submit</button>
        </div>
      )}
      {gameOver && <h3>Game Over! Thanks for playing.</h3>}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<TheListGame />);
